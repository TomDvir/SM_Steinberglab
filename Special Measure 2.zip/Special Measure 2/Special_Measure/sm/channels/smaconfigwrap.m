function scan = smaconfigwrap(scan, fn, varargin)
fn(varargin{:});
