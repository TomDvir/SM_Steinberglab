function smatrigDAC(daqs)

smcDecaDAC3([daqs 1], 0); 
smcDecaDAC3([daqs 1], 5);

%fprintf(smdata.inst(tds).data.inst, 'TRIG FORCE');
